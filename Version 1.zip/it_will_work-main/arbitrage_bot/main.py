from arbitrage import ArbitrageBot

if __name__ == "__main__":
    bot = ArbitrageBot()
    bot.start_monitoring()
